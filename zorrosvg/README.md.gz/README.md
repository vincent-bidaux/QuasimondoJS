ZorroSVG
============

The source code for: http://quasimondo.com/ZorroSVG/

This is not cleaned up or documented at all, but if you are interested in making a standalone version
or your own flavour of it, you'll find all of the required code inside of js/zorrosvgmaskmaker.js

I've not added all the jQuery/foundation etc. code to the repository - I mean it's shameful enough that
I used jQuery for the UI in the first place ;-)

Please let me know whenever you make improvements to the code or port it.

